import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Tracuubenh',
  templateUrl: './Tracuubenh.component.html',
  styleUrls: ['./Tracuubenh.component.css']
})
export class TracuubenhComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
