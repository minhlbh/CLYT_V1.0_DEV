import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forum-bar',
  templateUrl: './forum-bar.component.html',
  styleUrls: ['./forum-bar.component.css']
})
export class ForumBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
