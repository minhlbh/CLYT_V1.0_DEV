import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chi-tiet-benh',
  templateUrl: './chi-tiet-benh.component.html',
  styleUrls: ['./chi-tiet-benh.component.css']
})
export class ChiTietBenhComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
