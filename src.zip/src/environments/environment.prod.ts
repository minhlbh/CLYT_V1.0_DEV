export const environment = {
  production: true,
  apiUrl: 'http://api.truongkhoa.com/api/'
};
